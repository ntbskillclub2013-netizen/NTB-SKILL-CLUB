export const STATUS_TYPES = [
  "SUCCESS",
  "WARNING",
  "DANGER",
  "INFO",
  "PENDING",
  "NEUTRAL"
] as const;

export type StatusType = (typeof STATUS_TYPES)[number];
