export const vi = {
  loading: "Đang tải dữ liệu...",
  empty: "Chưa có dữ liệu",
  error: "Không thể hoàn thành thao tác. Vui lòng thử lại."
} as const;
