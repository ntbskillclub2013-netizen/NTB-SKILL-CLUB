export function required(value: string, message = "Trường này không được để trống") {
  return value.trim().length > 0 ? null : message;
}
