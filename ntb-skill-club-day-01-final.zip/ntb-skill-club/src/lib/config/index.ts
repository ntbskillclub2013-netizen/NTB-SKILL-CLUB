export const appConfig = {
  name: "NTB SKILL CLUB",
  locale: "vi-VN"
} as const;
