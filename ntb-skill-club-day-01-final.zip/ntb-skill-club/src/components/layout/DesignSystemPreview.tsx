"use client";

import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { ErrorState } from "@/components/ui/ErrorState";
import { Input } from "@/components/ui/Input";
import { LoadingState } from "@/components/ui/LoadingState";
import { Select } from "@/components/ui/Select";
import { Textarea } from "@/components/ui/Textarea";
import { StatusBadge } from "@/components/status/StatusBadge";
import { StatusBanner } from "@/components/status/StatusBanner";
import { StatusCard } from "@/components/status/StatusCard";
import { StatusRow } from "@/components/status/StatusRow";
import { Dialog } from "@/components/ui/Dialog";
import { useState } from "react";
import { STATUS_TYPES, type StatusType } from "@/lib/types/status";

export function DesignSystemPreview() {
  const [dialogOpen, setDialogOpen] = useState(false);
  return (
    <main className="preview">
      <header className="hero">
        <p className="eyebrow">NTB SKILL CLUB</p>
        <h1>Design System Preview</h1>
        <p style={{ marginTop: 10, color: "var(--color-muted)" }}>
          Nền móng giao diện DAY 01 — chưa có dữ liệu nghiệp vụ.
        </p>
      </header>

      <section className="section">
        <h2>Buttons & Badges</h2>
        <Card>
          <div className="button-row">
            <Button>Thao tác chính</Button>
            <Button variant="secondary">Phụ</Button>
            <Button variant="ghost">Bỏ qua</Button>
            <Button variant="danger">Xóa</Button>
            <Badge>Thẻ dùng chung</Badge>
          </div>
        </Card>
      </section>

      <section className="section">
        <h2>Statuses</h2>
        <div className="grid grid-3">
          {STATUS_TYPES.map((status) => (
            <StatusCard key={status} status={status as StatusType}>
              <StatusBadge status={status as StatusType} />
            </StatusCard>
          ))}
        </div>
        <Card style={{ marginTop: 16 }}>
          {STATUS_TYPES.map((status) => (
            <StatusRow key={status} label={`Trạng thái ${status}`} status={status as StatusType} />
          ))}
        </Card>
        <div style={{ marginTop: 16 }}>
          <StatusBanner status="INFO">Foundation đang sẵn sàng cho các module của những ngày sau.</StatusBanner>
        </div>
      </section>

      <section className="section">
        <h2>Loading / Empty / Error</h2>
        <div className="grid grid-3">
          <Card><LoadingState /></Card>
          <Card><EmptyState /></Card>
          <Card><ErrorState /></Card>
        </div>
      </section>

      <section className="section">
        <h2>Dialog / Modal</h2>
        <Card>
          <Button onClick={() => setDialogOpen(true)}>Mở hộp thoại</Button>
          <Dialog open={dialogOpen} title="Hộp thoại mẫu" onClose={() => setDialogOpen(false)}>
            <p>Hộp thoại dùng chung hỗ trợ focus, phím Escape và nút đóng.</p>
          </Dialog>
        </Card>
      </section>

      <section className="section">
        <h2>Form Controls</h2>
        <Card>
          <div className="grid grid-2">
            <div>
              <div className="control">
                <label htmlFor="name">Tên hiển thị</label>
                <Input id="name" placeholder="Nhập tên" />
              </div>
              <div className="control">
                <label htmlFor="role">Vai trò</label>
                <Select id="role" defaultValue="member">
                  <option value="member">Thành viên</option>
                  <option value="staff">Ban tổ chức</option>
                </Select>
              </div>
            </div>
            <div className="control">
              <label htmlFor="note">Ghi chú</label>
              <Textarea id="note" placeholder="Nhập ghi chú..." />
            </div>
          </div>
        </Card>
      </section>
    </main>
  );
}
