export function LoadingState() {
  return <div role="status" aria-live="polite" style={{ padding: 24, textAlign: "center" }}>Đang tải dữ liệu...</div>;
}
