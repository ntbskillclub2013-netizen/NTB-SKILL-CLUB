import { render, screen } from "@testing-library/react";
import { Badge } from "./Badge";
import { Button } from "./Button";
import { Card } from "./Card";
import { EmptyState } from "./EmptyState";
import { ErrorState } from "./ErrorState";
import { Input } from "./Input";
import { LoadingState } from "./LoadingState";
import { Select } from "./Select";
import { Textarea } from "./Textarea";

it("renders the shared UI foundation", () => {
  render(
    <Card>
      <Button>Thao tác</Button>
      <Badge>Badge</Badge>
      <label htmlFor="input">Tên</label><Input id="input" />
      <label htmlFor="select">Vai trò</label><Select id="select"><option>Thành viên</option></Select>
      <label htmlFor="textarea">Ghi chú</label><Textarea id="textarea" />
      <EmptyState />
      <LoadingState />
      <ErrorState />
    </Card>
  );
  expect(screen.getByRole("button", { name: "Thao tác" })).toBeInTheDocument();
  expect(screen.getByText("Badge")).toBeInTheDocument();
  expect(screen.getByLabelText("Tên")).toBeInTheDocument();
  expect(screen.getByLabelText("Vai trò")).toBeInTheDocument();
  expect(screen.getByLabelText("Ghi chú")).toBeInTheDocument();
  expect(screen.getByText("Chưa có dữ liệu")).toBeInTheDocument();
  expect(screen.getByText("Đang tải dữ liệu...")).toBeInTheDocument();
  expect(screen.getByRole("alert")).toBeInTheDocument();
});
