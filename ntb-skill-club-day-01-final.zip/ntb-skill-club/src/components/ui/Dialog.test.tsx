import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Dialog } from "./Dialog";

it("supports close button, Escape and focus restoration", async () => {
  const user = userEvent.setup();
  const trigger = document.createElement("button");
  trigger.textContent = "Mở";
  document.body.appendChild(trigger);
  trigger.focus();
  const onClose = jest.fn();

  render(<Dialog open title="Hộp thoại" onClose={onClose}><button>Hành động</button></Dialog>);
  expect(screen.getByRole("dialog", { name: "Hộp thoại" })).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "Đóng hộp thoại" })).toHaveFocus();

  fireEvent.keyDown(document, { key: "Escape" });
  expect(onClose).toHaveBeenCalled();

  await user.click(screen.getByRole("button", { name: "Đóng hộp thoại" }));
  expect(onClose).toHaveBeenCalledTimes(2);
  trigger.remove();
});
