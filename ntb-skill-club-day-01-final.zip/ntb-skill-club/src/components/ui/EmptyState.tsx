export function EmptyState({ message = "Chưa có dữ liệu" }: { message?: string }) {
  return <div role="status" style={{ padding: 24, textAlign: "center", color: "var(--color-muted)" }}>📋 {message}</div>;
}
