import type { ButtonHTMLAttributes } from "react";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
};

export function Button({ variant = "primary", className = "", ...props }: Props) {
  const styles = {
    primary: { background: "var(--color-primary)", color: "var(--color-on-primary)" },
    secondary: { background: "var(--color-secondary)", color: "var(--color-on-primary)" },
    ghost: { background: "transparent", color: "var(--color-foreground)" },
    danger: { background: "var(--color-danger)", color: "var(--color-on-primary)" }
  };

  return (
    <button
      {...props}
      className={className}
      style={{
        ...styles[variant],
        border: "1px solid var(--color-border)",
        borderRadius: "var(--radius-sm)",
        padding: "10px 16px",
        fontWeight: 700,
        cursor: props.disabled ? "not-allowed" : "pointer",
        opacity: props.disabled ? 0.6 : 1
      }}
    />
  );
}
