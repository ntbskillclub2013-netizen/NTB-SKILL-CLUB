export function ErrorState() {
  return (
    <div role="alert" style={{ padding: 16, borderRadius: "var(--radius-md)", background: "var(--color-danger)", border: "1px solid var(--color-danger-border)" }}>
      ⚠️ Không thể hoàn thành thao tác.<br />Vui lòng thử lại.
    </div>
  );
}
