import type { StatusType } from "@/lib/types/status";
import { statusConfig } from "./status-config";

export function StatusBadge({ status }: { status: StatusType }) {
  const config = statusConfig[status];
  return (
    <span
      aria-label={config.label}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 7,
        padding: "5px 10px",
        borderRadius: 999,
        background: config.background,
        border: `1px solid ${config.border}`,
        fontWeight: 700,
        fontSize: 12
      }}
    >
      <span aria-hidden="true">{config.icon}</span>
      {config.label}
    </span>
  );
}
