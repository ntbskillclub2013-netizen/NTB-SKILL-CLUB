import type { StatusType } from "@/lib/types/status";

export const statusConfig: Record<StatusType, { label: string; icon: string; background: string; border: string }> = {
  SUCCESS: { label: "THÀNH CÔNG", icon: "✓", background: "var(--color-success)", border: "var(--color-success-border)" },
  WARNING: { label: "CẢNH BÁO", icon: "!", background: "var(--color-warning)", border: "var(--color-warning-border)" },
  DANGER: { label: "QUÁ HẠN", icon: "×", background: "var(--color-danger)", border: "var(--color-danger-border)" },
  INFO: { label: "THÔNG TIN", icon: "i", background: "var(--color-info)", border: "var(--color-info-border)" },
  PENDING: { label: "ĐANG CHỜ", icon: "…", background: "var(--color-pending)", border: "var(--color-pending-border)" },
  NEUTRAL: { label: "TRUNG TÍNH", icon: "—", background: "var(--color-neutral)", border: "var(--color-neutral-border)" }
};
