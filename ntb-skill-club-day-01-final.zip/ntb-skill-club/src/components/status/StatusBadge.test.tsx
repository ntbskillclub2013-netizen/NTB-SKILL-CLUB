import { render, screen } from "@testing-library/react";
import { StatusBadge } from "./StatusBadge";

describe("StatusBadge", () => {
  it("renders the correct label for each status", () => {
    render(
      <div>
        <StatusBadge status="SUCCESS" />
        <StatusBadge status="WARNING" />
        <StatusBadge status="DANGER" />
        <StatusBadge status="INFO" />
        <StatusBadge status="PENDING" />
        <StatusBadge status="NEUTRAL" />
      </div>
    );

    expect(screen.getByText("THÀNH CÔNG")).toBeInTheDocument();
    expect(screen.getByText("CẢNH BÁO")).toBeInTheDocument();
    expect(screen.getByText("QUÁ HẠN")).toBeInTheDocument();
    expect(screen.getByText("THÔNG TIN")).toBeInTheDocument();
    expect(screen.getByText("ĐANG CHỜ")).toBeInTheDocument();
    expect(screen.getByText("TRUNG TÍNH")).toBeInTheDocument();
  });
});
