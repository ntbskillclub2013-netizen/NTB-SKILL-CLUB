import type { ReactNode } from "react";
import type { StatusType } from "@/lib/types/status";
import { statusConfig } from "./status-config";

export function StatusBanner({ status, children }: { status: StatusType; children: ReactNode }) {
  const config = statusConfig[status];
  return (
    <div role="status" style={{ padding: 14, borderRadius: "var(--radius-md)", background: config.background, border: `1px solid ${config.border}` }}>
      <strong>{config.icon} {config.label}:</strong> {children}
    </div>
  );
}
