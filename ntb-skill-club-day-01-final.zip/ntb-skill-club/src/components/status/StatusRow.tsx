import type { StatusType } from "@/lib/types/status";
import { StatusBadge } from "./StatusBadge";

export function StatusRow({ label, status }: { label: string; status: StatusType }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid var(--color-border)" }}>
      <span>{label}</span>
      <StatusBadge status={status} />
    </div>
  );
}
