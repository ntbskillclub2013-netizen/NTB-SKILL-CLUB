import { DesignSystemPreview } from "@/components/layout/DesignSystemPreview";

export default function Home() {
  return <DesignSystemPreview />;
}
