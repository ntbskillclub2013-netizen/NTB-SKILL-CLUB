# NTB SKILL CLUB

Nền tảng vận hành & quản trị nội bộ.

## DAY 01
Project foundation + design system + development control.

## Chạy local
```bash
npm install
npm run dev
```

## Kiểm tra
```bash
npm run lint
npm run test
npm run build
```
