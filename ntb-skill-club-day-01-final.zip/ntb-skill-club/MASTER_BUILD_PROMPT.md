# NTB SKILL CLUB — MASTER BUILD PROMPT

MASTER SPECIFICATION STATUS:
To be populated/maintained by project owner.

This file is reserved for the complete project specification. Day 01 does not invent business requirements that were not supplied.
